using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MIDIS.ORI.Entidades
{
	public partial class Banco_Request
	{
	    public Int32? IdBanco { get; set; }
		public String Sigla { get; set; }
		public String Nombre { get; set; }
	}


}