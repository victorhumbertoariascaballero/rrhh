﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MIDIS.ORI.Entidades
{
    public partial class NivelMinimo_Registro
    {
        public int iCodNivelMinimo { get; set; }
        public string strDescripcion { get; set; }
        public bool bEstado { get; set; }
    }
}
