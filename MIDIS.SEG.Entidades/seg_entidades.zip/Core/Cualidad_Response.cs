﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MIDIS.ORI.Entidades
{
    public partial class Cualidad_Response
    {
        public int iCodCualidad { get; set; }
        public string strNombre { get; set; }
        public string strDescripcion { get; set; }
        public bool bEstado { get; set; }

    }
}
