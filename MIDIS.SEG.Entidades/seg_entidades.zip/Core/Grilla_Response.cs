﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MIDIS.ORI.Entidades
{
    public class Grilla_Response
    {
        public Int64 TotalDeRegistros { get; set; }
        public Int64 NumeroDeFila { get; set; }
    }
}
