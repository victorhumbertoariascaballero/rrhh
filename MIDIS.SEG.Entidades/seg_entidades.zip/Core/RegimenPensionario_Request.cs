﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MIDIS.ORI.Entidades
{
   
    public partial class RegimenPensionario_Request
    {
        //public Int32 iCodAFP { get; set; }
        public Int32 iCodRegimenPen { get; set; }
        public String vNombre { get; set; }
        
        public Grilla_Request Grilla { get; set; }

        //public Int32 iCodRegistroRegimenPen { get; set; }
        //public Int32 iCodRegimenPen { get; set; }
        //public Int32 iCodTipoRegimenPen { get; set; }
        //public Int32 iCodAPF { get; set; }
        //public Int32 iMes { get; set; }
        //public Int32 iAnio { get; set; }
        //public String sNombre { get; set; }
        //public String sTipo { get; set; }
        //public Decimal dcComision { get; set; }
        //public Decimal dcPrimaSeguro { get; set; }
        //public Decimal dcAporte { get; set; }
        //public Decimal dcTope { get; set; }
        //public string sEtado { get; set; }
        //public bool bEstado { get; set; }

        //public Grilla_Request Grilla { get; set; }

        //public string iCodRegistroRegimenPen { get; set; }
        //public string iCodRegimenPen { get; set; }
        //public string iCodTipoRegimenPen { get; set; }
        //public string iCodAPF { get; set; }
        //public string iMes { get; set; }
        //public string iAnio { get; set; }
        //public string sNombre { get; set; }
        //public string sTipo { get; set; }
        //public string dcComision { get; set; }
        //public string dcPrimaSeguro { get; set; }
        //public string dcAporte { get; set; }
        //public string dcTope { get; set; }
        //public string sEtado { get; set; }
        //public bool bEstado { get; set; }

        //public Grilla_Request Grilla { get; set; }

    }
}
