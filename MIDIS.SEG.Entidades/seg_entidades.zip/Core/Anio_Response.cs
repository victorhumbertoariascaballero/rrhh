using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MIDIS.ORI.Entidades
{
	public partial class Anio_Response
	{
	    public String Anio { get; set; }
		
        public Grilla_Response Grilla { get; set; }
	}
}