﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MIDIS.ORI.Entidades
{
    public partial class BasesPerfilPuestoObservacionRegistro
    {
        public int iMaeBasesPerfilObservaciones { get; set; }
        public int iCodBasePerfil { get; set; }
        public string strObservacion { get; set; }
    }
}
