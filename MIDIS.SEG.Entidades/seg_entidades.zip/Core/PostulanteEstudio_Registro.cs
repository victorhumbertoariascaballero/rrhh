using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MIDIS.ORI.Entidades
{
    public partial class PostulanteEstudio_Registro
	{
	    public Int32 IdPostulante { get; set; }
        public Int32 IdEstudio { get; set; }
        public Int32 IdNivel { get; set; }
        public Int32 IdNoTieneTitulo { get; set; }
        public Int32 IdMes { get; set; }
        public Int32 IdAnio { get; set; }
        public String NombreGrado { get; set; }
        public String NombreNivel { get; set; }
        public String Especialidad { get; set; }
        public String Institucion { get; set; }
        public String Ciudad { get; set; }
        public Int32 Estado { get; set; }
        public String AnioMes { 
            get {
                String valor = String.Empty;

                switch (IdMes) { 
                    case 1: valor = String.Format("{0}-{1}", IdAnio.ToString(), "ENERO");
                        break;
                    case 2: valor = String.Format("{0}-{1}", IdAnio.ToString(), "FEBRERO");
                        break;
                    case 3: valor = String.Format("{0}-{1}", IdAnio.ToString(), "MARZO");
                        break;
                    case 4: valor = String.Format("{0}-{1}", IdAnio.ToString(), "ABRIL");
                        break;
                    case 5: valor = String.Format("{0}-{1}", IdAnio.ToString(), "MAYO");
                        break;
                    case 6: valor = String.Format("{0}-{1}", IdAnio.ToString(), "JUNIO");
                        break;
                    case 7: valor = String.Format("{0}-{1}", IdAnio.ToString(), "JULIO");
                        break;
                    case 8: valor = String.Format("{0}-{1}", IdAnio.ToString(), "AGOSTO");
                        break;
                    case 9: valor = String.Format("{0}-{1}", IdAnio.ToString(), "SEPTIEMBRE");
                        break;
                    case 10: valor = String.Format("{0}-{1}", IdAnio.ToString(), "OCTUBRE");
                        break;
                    case 11: valor = String.Format("{0}-{1}", IdAnio.ToString(), "NOVIEMBRE");
                        break;
                    case 12: valor = String.Format("{0}-{1}", IdAnio.ToString(), "DICIEMBRE");
                        break;
                }

                return valor;
            }  
        }
        
        public Int32? IdUsuarioRegistro { get; set; }
        public Int32? IdUsuarioModificacion { get; set; }
        public DateTime? FechaRegistro { get; set; }
        public DateTime? FechaModificacion { get; set; }
        public IEnumerable<object> formatos { get; set; }
        public Int32 IdTieneArchivo { get; set; }
        public byte[] FileArchivo { get; set; }
        
        public Grilla_Response Grilla { get; set; }
	}
}