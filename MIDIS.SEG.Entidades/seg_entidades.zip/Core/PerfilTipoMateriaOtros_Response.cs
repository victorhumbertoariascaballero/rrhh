﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MIDIS.ORI.Entidades
{
    public partial class PerfilTipoMateriaOtros_Response
    {
        public int iCodTipoMateriaOtros { get; set; }
        public string strDescripcion { get; set; }
        public bool bEstado { get; set; }
    }
}
