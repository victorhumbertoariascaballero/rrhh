﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MIDIS.ORI.Entidades
{
    public partial class PerfilGrados_Response
    {
        public int iCodGrado { get; set; }
        public string strDescripcion { get; set; }
        public bool bEstado { get; set; }
    }
}
