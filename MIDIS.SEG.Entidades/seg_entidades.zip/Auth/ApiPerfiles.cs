﻿namespace MIDIS.ORI.Entidades.Auth
{
    public class ApiPerfiles
    {
        public int iCodPer { get; set; }
        public string vNomPer { get; set; }
        public string vUbg { get; set; }
    }
}
