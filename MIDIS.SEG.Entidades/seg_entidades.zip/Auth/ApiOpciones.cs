﻿namespace MIDIS.ORI.Entidades.Auth
{
    public class ApiOpciones
    {
        public long iCodOpc { get; set; }
        public long iCodPer { get; set; }
        public string vNomOpc { get; set; }
        public string vURL { get; set; }
        public string vTitOpc { get; set; }
        public string vDirOpc { get; set; }
        public string iGrupOpc { get; set; }
        public string iNroOrd { get; set; }
    }
}