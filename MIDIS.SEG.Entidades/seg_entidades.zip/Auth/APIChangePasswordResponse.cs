﻿namespace MIDIS.ORI.Entidades.Auth
{
    public class APIChangePasswordResponse
    {
        public string vCodResponse { get; set; }
        public string vMensajeResponse { get; set; }
        public string Url { get; set; }
    }
}
